<?php defined('ALTUMCODE') || die() ?>
<hr />

<div class="mb-5">
    <span class="text-muted"><?= 'Copyright &copy; ' . date('Y') . ' ' . $settings->title . '. All rights reserved. Product by <a href="https://altumcode.io/">AltumCode</a>' ?></span>
</div>

</div>
