<?php
define('PRODUCT_NAME', 'phpAnalyzer');
define('PRODUCT_KEY', 'phpanalyzer');
define('PRODUCT_URL', 'https://altumcode.link/phpanalyzer');
define('PRODUCT_DOCUMENTATION_URL', 'https://altumcode.link/phpanalyzer-docs');
define('PRODUCT_VERSION', '3.1.4 💻');
define('PRODUCT_CODE', '314');
