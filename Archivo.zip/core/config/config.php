<?php

$config = [
    'database_host'        => 'localhost',
    'database_username'    => '',
    'database_password'    => '',
    'database_name'        => '',
    'url'                  => ''
];
