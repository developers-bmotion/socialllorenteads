<?php

$controller_has_view = false;

$captcha = new Captcha;

$captcha->process();