<?php
defined('ALTUMCODE') || die();

User::logout();
