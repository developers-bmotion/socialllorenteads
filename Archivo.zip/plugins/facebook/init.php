<?php
defined('ALTUMCODE') || die();

require_once ROOT . PLUGINS_ROUTE . 'facebook/core/classes/Facebook.php';
require_once ROOT . PLUGINS_ROUTE . 'facebook/core/functions/simple_html_dom.php';
