<?php
defined('ALTUMCODE') || die();

require_once ROOT . PLUGINS_ROUTE . 'youtube/core/classes/YouTube.php';
